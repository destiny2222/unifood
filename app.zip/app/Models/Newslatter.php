<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Newslatter extends Model
{
    public $fillable = [
        'email'
    ];
}
