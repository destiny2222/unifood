<!--=============================
        BREADCRUMB START
    ==============================-->
    <section class="wsus__breadcrumb" style="background: url(<?php echo e(asset('images/breadcrumb_image.jpg')); ?>);">
        <div class="wsus__breadcrumb_overlay">
            <div class="container">
                <div class="wsus__breadcrumb_text">
                    <h1><?php echo $__env->yieldContent('title', ''); ?></h1>
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li><a href="#"><?php echo $__env->yieldContent('title', ''); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--=============================
        BREADCRUMB END
    ==============================--><?php /**PATH C:\xampp\htdocs\unifood\resources\views/partials/breadcrumb.blade.php ENDPATH**/ ?>