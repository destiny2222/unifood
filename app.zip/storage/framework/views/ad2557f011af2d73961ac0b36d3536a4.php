
<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('user/css/product.css')); ?>">
    <?php $__env->stopPush(); ?>
<?php $__env->startSection('title', 'Product'); ?>
<!--=============================
            BREADCRUMB START
        ==============================-->
<?php echo $__env->make('partials.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!--=============================
        BREADCRUMB END
    ==============================-->



<!--shop grid section start-->
<section class="gshop-gshop-grid mt_120 xs_mt_90 mb_100 xs_mb_70">
    <div class="container">
        <div class="row g-4">

            <div class="col-xl-3 order-xl-1 order-lg-1 order-md-1 order-sm-2 order-2">
                <div class="" id="desktop_version">
                    <div class="gshop-sidebar bg-white rounded-2 overflow-hidden">
                        <!--Filter by search-->
                        <div class="sidebar-widget search-widget bg-white py-5 px-4">
                            <div class="widget-title d-flex">
                                <h6 class="mb-0 flex-shrink-0">Search Now</h6>
                                <span class="hr-line w-100 position-relative d-block align-self-end ms-1"></span>
                            </div>
                            <form class="search-form d-flex align-items-center mt-4"  action="<?php echo e(route('search')); ?>" method="GET">
                                <input type="text" id="search" name="search" placeholder="Search">
                                <button type="submit" class="submit-icon-btn-secondary">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>
                        <!--Filter by search-->
                        <!--Filter by Categories-->
                        <div class="sidebar-widget category-widget bg-white py-5 px-4 border-top mobile-menu-wrapper scrollbar h-400px">
                            <div class="widget-title d-flex">
                                <h6 class="mb-0 flex-shrink-0">Categories</h6>
                                <span class="hr-line w-100 position-relative d-block align-self-end ms-1"></span>
                            </div>
                            <ul class="widget-nav mt-4">
                                
                                <li>
                                    <a href="<?php echo e(route('frontend.product')); ?>" 
                                    class="d-flex justify-content-between align-items-center <?php echo e(!request()->has('category') ? 'active' : ''); ?>">
                                        All Categories
                                        <span class="fw-bold fs-xs total-count"><?php echo e($categories->sum('product_count')); ?></span>
                                    </a>
                                </li>
                                
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li>
                                        <a href="<?php echo e(route('products.by.category', $category->slug)); ?>" 
                                        class="d-flex justify-content-between align-items-center <?php echo e(request()->get('category') == $category->slug ? 'active' : ''); ?>">
                                            <?php echo e($category->title); ?>

                                            <span class="fw-bold fs-xs total-count"><?php echo e($category->product_count); ?></span>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li>
                                        <span class="text-muted">No categories available</span>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <!--Filter by Categories-->

                        <!--Filter by Price-->
                        
                        <!--Filter by Price-->
                    </div>
                </div>
            </div>

            <!--rightbar-->
            <div class="col-xl-9 order-xl-2 order-lg-2 order-md-2 order-sm-1 order-1">
                <div class="shop-grid">
                    <!--products-->
                    <div class="row g-4">
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-lg-4 col-md-6 col-sm-10 mb-5">
                                <div class="vertical-product-card rounded-2 position-relative swiper-slide bg-white">
                                    <div class="thumbnail position-relative text-center p-4">
                                        <a href="<?php echo e(route('frontend.product.show', $product->slug)); ?>">
                                            <img src="<?php echo e($product->images); ?>" alt="Badhakopi (Cabbage)" class="img-fluid">
                                        </a>
                                        <div class="product-btns position-absolute d-flex gap-2 flex-column">
                                            <a href="<?php echo e(route('wishlist.add')); ?>"
                                                onclick="event.preventDefault(); document.getElementById('wish-<?php echo e($product->id); ?>').submit()"
                                                class="rounded-btn">
                                                <i class="fa fa-heart"></i>
                                            </a>
                                            <form action="<?php echo e(route('wishlist.add')); ?>" id="wish-<?php echo e($product->id); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                            </form>
                                            <a href="<?php echo e(route('frontend.product.show', $product->slug)); ?>"
                                                class="rounded-btn">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="card-content">
                                        <!--product category start-->
                                        <div class="mb-2 tt-category tt-line-clamp tt-clamp-1">
                                            <a href="<?php echo e(route('frontend.product.show', $product->slug)); ?>"
                                                class="d-inline-block text-muted fs-xxs">
                                                <?php echo e($product->category->title ?? 'Uncategorized'); ?>

                                            </a>
                                        </div>
                                        <!--product category end-->

                                        <a href="<?php echo e(route('frontend.product.show', $product->slug)); ?>"
                                            class="card-title fw-semibold mb-2 tt-line-clamp tt-clamp-1">
                                            <?php echo e($product->title); ?>

                                        </a>

                                        <h6 class="price">
                                            <span class="fw-bold h4 text-success">£<?php echo e(number_format($product->variants->first()->price ?? 0, 2)); ?>

                                                <?php if($product->discount): ?>
                                                    <del>£<?php echo e($product->discount); ?></del>
                                                <?php endif; ?>
                                            </span>
                                            <small>/<?php echo e($product->variants->first()->unit ?? 'pcs'); ?></small>
                                        </h6>
                                        <div class="d-flex gap-3 justify-content-between align-items-center">
                                            <button type="button" onclick="event.preventDefault(); load_product_model(<?php echo e(json_encode($product->slug)); ?>)"
                                                class="btn btn_outline_secondary btn-md border-secondary d-block mt-4 w-100 direct-add-to-cart-btn add-to-cart-text">
                                                Add to Cart
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12 text-center">
                                <p>No products found.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="d-sm-block d-lg-flex align-items-center justify-content-between mt-7 tt-custom-pagination">
                        <span>
                            Showing <?php echo e($products->firstItem()); ?>-<?php echo e($products->lastItem()); ?> of <?php echo e($products->total()); ?> results
                        </span>
                        
                        <?php if($products->hasPages()): ?>
                            <nav>
                                <ul class="pagination">
                                    
                                    <?php if($products->onFirstPage()): ?>
                                        <li class="page-item disabled" aria-disabled="true" aria-label="« Previous">
                                            <span class="page-link" aria-hidden="true">‹</span>
                                        </li>
                                    <?php else: ?>
                                        <li class="page-item">
                                            <a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>" rel="prev" aria-label="« Previous">‹</a>
                                        </li>
                                    <?php endif; ?>

                                    
                                    <?php $__currentLoopData = $products->getUrlRange(1, $products->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($page == $products->currentPage()): ?>
                                            <li class="page-item active" aria-current="page"><span class="page-link"><?php echo e($page); ?></span></li>
                                        <?php else: ?>
                                            <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    
                                    <?php if($products->hasMorePages()): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>" rel="next" aria-label="Next »">›</a>
                                        </li>
                                    <?php else: ?>
                                        <li class="page-item disabled" aria-disabled="true" aria-label="Next »">
                                            <span class="page-link" aria-hidden="true">›</span>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!--rightbar-->

        </div>
    </div>
</section>
<!--shop grid section end-->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<script>
    function load_product_model(product_slug){

        $("#preloader").addClass('preloader')
        $(".img").removeClass('d-none')

        $.ajax({
            type: 'get',
            url: "<?php echo e(url('product')); ?>/" + product_slug,
            success: function (response) {
                $("#preloader").removeClass('preloader')
                $(".img").addClass('d-none')
                $(".load_product_modal_response").html(response)
                $("#cartModal").modal('show');
            },
            error: function(response) {
                toastr.error("Server error occured")
                $(".img").addClass('d-none')
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\unifood\resources\views/frontend/product.blade.php ENDPATH**/ ?>