<div>
    <div class="wsus__menu_cart_boody">
        <!--[if BLOCK]><![endif]--><?php if(count($carts) > 0): ?>
            <div class="wsus__menu_cart_header">
                <h5 class="mini_cart_body_item">Total Item(<?php echo e(count($carts)); ?>)</h5>
                <span class="close_cart"><i class="fal fa-times" aria-hidden="true"></i></span>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]--> 
    
        <ul class="mini_cart_list">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartId => $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $product = $products[$cartId] ?? null;
                    $subtotal = $cartItem['price'] * $cartItem['quantity'];
                ?>

                <!--[if BLOCK]><![endif]--><?php if($product): ?>
                <li class="min-item mb-5">
                    <div class="menu_cart_img">
                        <img src="<?php echo e($product->images); ?>" alt="menu" class="img-fluid w-100">
                    </div>
                    <div class="menu_cart_text">
                        <a class="title" href="<?php echo e(route('frontend.product.show', $product->slug)); ?>">
                            <?php echo e(\Str::limit($product->title, 50)); ?>

                        </a>
                        <div class="d-flex align-items-center" style="column-gap: 10px;">
                            <span class="quantity"><?php echo e($cartItem['quantity']); ?> x</span>
                            <p class="price mini-price">£<?php echo e(number_format($cartItem['price'], 2)); ?></p>
                        </div>
                    </div>
                    <button class="del_icon mini-item-remove" wire:click="removeItem('<?php echo e($cartId); ?>')">
                        <i class="fal fa-times" aria-hidden="true"></i>
                    </button>
                </li>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="wsus__menu_cart_header">
                    <h5>Your shopping cart is empty!</h5>
                    <span class="close_cart"><i class="fal fa-times"></i></span>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </ul>

        <!--[if BLOCK]><![endif]--><?php if(count($carts) > 0): ?>
            <p class="subtotal">Sub Total <span class="mini_sub_total">$<?php echo e(number_format($total, 2)); ?></span></p>
            <a class="cart_view" href="<?php echo e(route('cart.index')); ?>"> view cart</a>
            <a class="checkout" href="<?php echo e(route('checkout')); ?>">checkout</a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\unifood\resources\views/livewire/mini-cart.blade.php ENDPATH**/ ?>